# DEVELOPMENT_LOEO

Evidence status: **COMPLETE**. Research gate: **FAILED_HYPOTHESIS**.

Verified neural cells: 504/504; analytic age-prior folds: 24/24; invalid cells: 0.

All inputs and predictions are development-only. No official TEST was opened by this collector.

Primary: within each seed, average the six held-out-engine RMSEs; then report the three-seed mean and sample SD. Flight-pooled RMSE and NASA sum/mean are separate. Analytic age prior is deterministic, with no artificial seed replicates.

|Subset|Mode|Raw engine-mean RMSE|Between-seed SD|Evidence|
|---|---|---:|---:|---|
|DS02|raw|8.39741|1.01476|COMPLETE|
|DS02|fe|9.40602|0.243249|COMPLETE|
|DS02|delta|9.20998|0.653831|COMPLETE|
|DS02|supported|10.6402|0.818476|COMPLETE|
|DS02|common|9.85543|1.18513|COMPLETE|
|DS02|age|9.16358|0.123787|COMPLETE|
|DS02|w_only|9.77504|0.409897|COMPLETE|
|DS02|age_prior|8.92667|missing|COMPLETE|
|DS05|raw|8.81892|0.469626|COMPLETE|
|DS05|fe|10.8752|0.313921|COMPLETE|
|DS05|delta|8.10376|1.49365|COMPLETE|
|DS05|supported|13.1744|1.79675|COMPLETE|
|DS05|common|12.1088|1.24232|COMPLETE|
|DS05|age|13.9948|0.360761|COMPLETE|
|DS05|w_only|12.2486|0.301075|COMPLETE|
|DS05|age_prior|13.5927|missing|COMPLETE|
|DS06|raw|8.81046|0.223704|COMPLETE|
|DS06|fe|9.82231|1.6026|COMPLETE|
|DS06|delta|9.09556|0.784791|COMPLETE|
|DS06|supported|10.782|0.828878|COMPLETE|
|DS06|common|11.078|0.378888|COMPLETE|
|DS06|age|11.2031|0.327272|COMPLETE|
|DS06|w_only|10.2437|0.297581|COMPLETE|
|DS06|age_prior|10.6618|missing|COMPLETE|
|DS07|raw|9.02852|0.516717|COMPLETE|
|DS07|fe|9.34373|0.0977754|COMPLETE|
|DS07|delta|7.46893|0.556061|COMPLETE|
|DS07|supported|6.60839|0.626792|COMPLETE|
|DS07|common|7.5283|0.725165|COMPLETE|
|DS07|age|6.09732|0.113216|COMPLETE|
|DS07|w_only|8.29597|0.290311|COMPLETE|
|DS07|age_prior|5.89585|missing|COMPLETE|

|Subset|Common versus|Paired RMSE delta (common-control)|Engine-bootstrap 95% interval|Gain %|
|---|---|---:|---|---:|
|DS02|raw|1.45802|[-1.93364, 4.99331]|-17.3627|
|DS02|fe|0.449414|[-2.59693, 3.49755]|-4.77794|
|DS02|delta|0.645456|[-1.62408, 2.8946]|-7.00822|
|DS02|supported|-0.784727|[-1.75557, 0.161607]|7.37515|
|DS02|age|0.691855|[-1.56618, 2.95908]|-7.55006|
|DS02|age_prior|0.928765|[-1.30756, 3.03923]|-10.4044|
|DS02|w_only|0.0803878|[-4.42092, 4.81075]|-0.822378|
|DS05|raw|3.28993|[-0.832432, 8.93423]|-37.3053|
|DS05|fe|1.2337|[-3.16791, 6.69377]|-11.3442|
|DS05|delta|4.00509|[1.81144, 7.02197]|-49.4226|
|DS05|supported|-1.06557|[-2.38518, 0.0734684]|8.08821|
|DS05|age|-1.88591|[-6.82517, 2.72246]|13.4758|
|DS05|age_prior|-1.48382|[-7.185, 4.27289]|10.9163|
|DS05|w_only|-0.139778|[-4.19519, 6.06728]|1.14117|
|DS06|raw|2.26749|[0.373281, 4.40233]|-25.7363|
|DS06|fe|1.25564|[-0.68223, 3.14142]|-12.7835|
|DS06|delta|1.98239|[0.800628, 3.09719]|-21.7952|
|DS06|supported|0.295979|[-0.508665, 1.11156]|-2.74513|
|DS06|age|-0.125123|[-3.32844, 2.60019]|1.11686|
|DS06|age_prior|0.416199|[-3.14506, 4.31908]|-3.90366|
|DS06|w_only|0.834212|[-2.55236, 5.26307]|-8.14362|
|DS07|raw|-1.50022|[-2.85832, -0.360572]|16.6165|
|DS07|fe|-1.81543|[-2.64674, -0.949622]|19.4294|
|DS07|delta|0.0593676|[-0.343325, 0.538869]|-0.79486|
|DS07|supported|0.919905|[0.39857, 1.35432]|-13.9203|
|DS07|age|1.43098|[-1.02091, 3.70277]|-23.469|
|DS07|age_prior|1.63245|[-1.22908, 4.2656]|-27.6881|
|DS07|w_only|-0.76767|[-1.99271, 0.42899]|9.25354|

Bootstrap first averages paired differences over seeds within each engine, then resamples the six engines (10000 draws, percentile 95% intervals). The six LOEO training sets overlap; these are descriptive clustered intervals, not independent-fold hypothesis tests. Seeds are not engines. No p-values or significance claims.

## Frozen gates

|Gate|Status|
|---|---|
|primary|FAIL|
|age_references|FAIL|
|sensor_specificity_gate|FAIL|
|attribution|FAIL|
|mechanism|FAIL|

Primary requires common jointly >=2% better than raw and FE on the same >=2 subsets; attribution similarly requires delta and supported. No control/subset may be worse by >2%. Common must strictly beat both age references on every subset. Common must also strictly beat W-only on every subset. W-only retains W/coverage/age and the same temporal head, zeroes Xs and disables its auxiliary loss; it is a reference, not a matched H-attribution arm. Mechanism requires the same >=2 subsets jointly passing all FE/delta/supported controls: >=25% density-drift reduction, control drift >=0.05 cycles, positive clean gain, unpaired relative gain <=half clean gain, and perturbed common RMSE no >2% worse. Missing evidence blocks a full PASS. Near-zero control drift is not identifiable.

## Observed rank and weighting

|Subset|Statistic (common, clean)|Mean of cell means|Minimum|Maximum|Cells|
|---|---|---:|---:|---:|---:|
|DS02|common_rank|3.94542|0|4|18|
|DS02|projection_removed_norm|1.67457e-07|0|2.10312e-06|18|
|DS02|rank_below_latent_fraction|0.0136456|0.011236|0.015873|18|
|DS02|supported_fraction|0.984132|0.973333|0.988764|18|
|DS02|weighting_change_norm|0.457471|0|5.74498|18|
|DS02|weighting_relative_change|0.647335|0|1.42682|18|
|DS05|common_rank|3.94973|0|4|18|
|DS05|projection_removed_norm|1.36215e-07|0|1.51729e-06|18|
|DS05|rank_below_latent_fraction|0.0125685|0.01|0.0153846|18|
|DS05|supported_fraction|0.987431|0.984615|0.99|18|
|DS05|weighting_change_norm|0.393901|0|2.43774|18|
|DS05|weighting_relative_change|0.67691|0|1.6194|18|
|DS06|common_rank|3.94845|0|4|18|
|DS06|projection_removed_norm|1.37281e-07|0|1.27977e-06|18|
|DS06|rank_below_latent_fraction|0.0128878|0.010101|0.0153846|18|
|DS06|supported_fraction|0.987112|0.984615|0.989899|18|
|DS06|weighting_change_norm|0.393084|0|3.35142|18|
|DS06|weighting_relative_change|0.66255|0|1.48099|18|
|DS07|common_rank|3.94837|0|4|18|
|DS07|projection_removed_norm|1.11155e-07|0|8.26578e-07|18|
|DS07|rank_below_latent_fraction|0.0129078|0.0117647|0.0149254|18|
|DS07|supported_fraction|0.987092|0.985075|0.988235|18|
|DS07|weighting_change_norm|0.320075|0|1.39999|18|
|DS07|weighting_relative_change|0.717618|0|1.67025|18|

Only the controller's actual per-tensor mean/minimum/maximum summaries are available. No per-flight rank histogram, conditional weighting distribution, uncertainty calibration or physical-health interpretation is inferred. All available diagnostics are preserved in diagnostics_cells.csv and diagnostics_summary.csv.

## Resource and evidence limits

Recorded training time: 41.0094 process-hours, excluding evaluation and unrecorded preparation/overhead. Registered maximum: 36 hours. Per-cell parameters, optimizer updates, memory and seals are in cells.csv.

Total parameters include inactive branches. cells.csv retains the controller's encoder report and a separate task-only W-only count: Xs-zero input plus disabled auxiliary loss leaves 8704 effective encoder parameters (79937 including head), versus total 12842/84075. These structural counts do not remove sample-dependent support fallbacks or saturation.

Four external-paper baselines are source-audited separately; their uniform-protocol training is not established by this response-module report.

Invalid/missing caches, cells, unavailable CPU checkpoint validation and missing diagnostics are listed in summary.json. No partial matrix is promoted to a complete comparison or a validated novel mechanism.
